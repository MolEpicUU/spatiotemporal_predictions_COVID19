
## +++ Random Forest, cumulative calculations

# uwe.menzel@medsci.uu.se   11/2021




## Files:

infile = "prediction_ServicePoints_Vacc_20211109.csv"
tuning_file = "tuning_RF.txt"
warn_file = "warnings_RF.txt"

  

## Time:

start_time = Sys.time()



## Functions:

ff = "RF_GB_aux.R"
if(!file.exists(ff)) stop("Functions file not found.")
source(ff)




## Libraries:

library(caret) 
library(car)    
library(VennDiagram)
library(missForest)
# library(doMC)     # Server, distributed computing 
# registerDoMC(cores = 16)    




## Data: 

if(!file.exists(infile)) stop("Missing input file.")
cat(paste("Loading file", infile, "\n"))
# data = read.csv(infile, header = TRUE, stringsAsFactors = FALSE, dec = ".", fileEncoding = "ISO-8859-1")  # server
data = read.csv(infile, header = TRUE, stringsAsFactors = FALSE, dec = ".")  
data$X <- NULL
str(data)




## Explore data: 

dim(data)                 # 2700 31
range(data[["week"]])     # 26 79  
first_week = 27           




## Cumulative calculations:

method = "rf"
metric = "RMSE" 

tg <- expand.grid(mtry = seq(1, 15))   # to be adjusted
ctrl <- trainControl(method = "repeatedcv", number = 10, repeats = 5, verboseIter = TRUE)  
skip_reg = c("Service_Point_name", "week", "ECDC_Colour", "kommun", "top10_code_nextweek", "cases_per_capita_1w5_nextweek", "Antalpatienter_nextweek", "ServicePoint_postalcode")
reg_results = data.frame(testweek = integer(), Rsquared = numeric(), RMSE = numeric(), mtry = integer()) 
best.10 = list() 
  
for (last_week in 31:max(data$week)) {              
  
  weeklydata = select_weeks(data, from = first_week, to = last_week)

  first_train_week = first_week
  testweek = max(weeklydata$week)              
  cat(paste("\n ======= Testweek: ", testweek, " ====== \n"))        

  traindat_reg = training_data_regression(weeklydata, first_train_week, testweek, skip_reg, impute = FALSE)

  imp = missForest(traindat_reg)$ximp  # imputation
  traindat_reg = imp
  if(sum(is.na(traindat_reg)) > 0) stop("Still missing values in dataset.")

  true_values = data[data$week == testweek, c("Service_Point_name", "positivity_1w_nextweek")]
  rownames(true_values) = true_values$Service_Point_name

  testdat_reg = test_data_reg(weeklydata, testweek, skip_reg)     
  rem = colnames(testdat_reg)[which(!colnames(testdat_reg) %in% colnames(traindat_reg))]
  for (var in rem) testdat_reg[,var] <- NULL

  if(ncol(traindat_reg) != (ncol(testdat_reg) + 1)) stop("Different variables in test- and training data.")
  if(!all(c(colnames(testdat_reg), "positivity_1w_nextweek") == colnames(traindat_reg))) stop("Different variables in test- and training data.") 

  sink(tuning_file) 
  rf_fit_reg <- caret::train(positivity_1w_nextweek ~ ., data = traindat_reg, method = method, 
                             verbose = FALSE, metric = metric, trControl = ctrl, tuneGrid = tg, ntree = 1000)			      			      
  sink()

  sink(warn_file)
  warnings()  
  sink()

  fn1 = paste0("rf_fit_reg_w", testweek, ".RData")
  save(rf_fit_reg, file = fn1) 

  Rsquared = Rsquared_RF_tuned(rf_fit_reg)  # from training   
 
  rf_reg_res = predict(rf_fit_reg, newdata = testdat_reg)         
  names(rf_reg_res) = rownames(testdat_reg)

  best.10[[paste0("testweek_", testweek)]] = head(sort(rf_reg_res, decreasing = TRUE), 10) 
  rmse = rmse_reg(rf_reg_res, true_values) 
  reg_row = data.frame(testweek = testweek, Rsquared = Rsquared, RMSE = rmse, mtry = rf_fit_reg$bestTune$mtry)
  reg_results = rbind(reg_results, reg_row)  
}     

fn = "reg_results_RF.RData"
save(reg_results, file = fn)
cat(paste("Main results:", fn, "\n\n"))

fn = "best.10_RF.RData"
save(best.10, file = fn)
cat(paste("Top 10 per week:", fn, "\n\n"))

end_time = Sys.time()
cat(paste("Runtime:", signif(end_time - start_time, 4), "\n\n"))





