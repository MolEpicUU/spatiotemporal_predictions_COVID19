
## +++ Plots, Gradient Boosting, Random Forest

# uwe.menzel@medsci.uu.se


infile = "prediction_ServicePoints_Vacc_20211109.csv"



## Libraries:

library(car)    
library(VennDiagram)
library(gbm)
library(missForest)



## Data: 

if(!file.exists(infile)) stop("Missing input file.")
cat(paste("Loading file", infile, "\n"))
# data = read.csv(infile, header = TRUE, stringsAsFactors = FALSE, dec = ".", fileEncoding = "ISO-8859-1")   # server
data = read.csv(infile, header = TRUE, stringsAsFactors = FALSE, dec = ".")   
data$X <- NULL
str(data)



## Functions:

ff = "RF_GB_aux.R"
if(!file.exists(ff)) stop("Functions file not found.")
source(ff)



## Load results from covid_GB.R and covid_RF.R 

fn = "reg_results_GB.RData"       
if(!file.exists(fn)) stop("No GB output file available.")
file.info(fn)[,c(1,5)]            
reg_results_GB = get(load(fn))

fn = "reg_results_RF.RData"       
if(!file.exists(fn)) stop("No RF output file available.")
file.info(fn)[,c(1,5)]            
reg_results_RF = get(load(fn))



## Save to csv

GB_csv = reg_results_GB[,c(1,3)]
RF_csv = reg_results_RF[,c(1,3)]
GB_RF_csv = merge(GB_csv, RF_csv, by.x = "testweek", by.y = "testweek")
colnames(GB_RF_csv) = c("testweek", "RMSE_GB", "RMSE_RF")  

fn = "GB_RF_RMSE.csv"
write.csv(GB_RF_csv, file = fn, row.names = FALSE)
file.info(fn)[,c(1,5)]   




## Rsquared:

ylim = c(min(c(reg_results_GB$Rsquared, reg_results_RF$Rsquared)), max(c(reg_results_GB$Rsquared, reg_results_RF$Rsquared)))

plot(reg_results_GB$testweek, reg_results_GB$Rsquared, type = "b", ylim = ylim,
        xlab = "week", ylab = "Rsquared", col = "red", main = "Rsquared", font.main = 1)

points(reg_results_RF$testweek, reg_results_RF$Rsquared, type = "b", ylim = ylim, col = "blue")
legend("bottomright", legend = c("GB", "RF"), col = c("red", "blue"), lty = 1, lwd = 2) 
 
  

## RMSE:

ylim = c(min(c(reg_results_GB$RMSE, reg_results_RF$RMSE), na.rm = TRUE), max(c(reg_results_GB$RMSE, reg_results_RF$RMSE), na.rm = TRUE))

plot(reg_results_GB$testweek, reg_results_GB$RMSE, type = "b", ylim = ylim,
     xlab = "week", ylab = "RMSE", col = "red", main = "RMSE", font.main = 1)

points(reg_results_RF$testweek, reg_results_RF$RMSE, type = "b", ylim = ylim, col = "blue")
legend("topright", legend = c("GB", "RF"), col = c("red", "blue"), lty = 1, lwd = 2) 


 


## Random Forest importance plots:

testweek = 79 
fn = paste0("rf_fit_reg_w", testweek, ".RData")
if(!file.exists(fn)) stop(paste("File", fn, "not available."))  
model = get(load(fn)) 

importance = data.frame(Variable = rownames(model$finalModel$importance), Importance = model$finalModel$importance[,1])
importance = importance[order(importance$Importance, decreasing = TRUE),]
importance$Variable = as.character(importance$Variable)
orig_margins = c(5, 4, 4, 2) + 0.1
par(mar = c(5, 9, 4, 2))  
barplot(importance$Importance, main="Random Forest, Relative Importance", las = 1, cex.names = 0.7, font.main = 1, horiz = TRUE, names.arg = importance$Variable, col = "blue")
par("mar" = orig_margins) 
write.csv(importance, file = paste0("Importance_RF_week", testweek, ".csv"), row.names = FALSE)

# Rank importance:

sum_of_ranks = rep(0, nrow(importance))
names(sum_of_ranks) = importance$Variable

weeks = 31:79

for (testweek in weeks) {                           
  cat(paste("Testweek", testweek, "\n"))
  fn = paste0("rf_fit_reg_w", testweek, ".RData")
  if(!file.exists(fn)) stop("Model not found.")   
  model = get(load(fn)) 
  importance = data.frame(Variable = rownames(model$finalModel$importance), Importance = model$finalModel$importance[,1], stringsAsFactors = FALSE)
  importance = importance[order(importance$Importance, decreasing = TRUE),]  
  for (i in 1:nrow(importance)) sum_of_ranks[importance$Variable[i]] = sum_of_ranks[importance$Variable[i]] + i
}

mean_of_ranks = sort(sum_of_ranks/length(weeks))

orig_margins = c(5, 4, 4, 2) + 0.1
par(mar = c(5, 9, 4, 2))  
barplot(mean_of_ranks, main="RF, Mean of Ranks of Variable Importance", las = 1, cex.names = 0.7, font.main = 1, horiz = TRUE, names.arg = names(mean_of_ranks), col = "blue")
par("mar" = orig_margins) 
df = data.frame(variable = names(mean_of_ranks), mean_rank = as.numeric(mean_of_ranks))
write.csv(df, file = "RF_mean_of_ranks.csv", row.names = FALSE)



## Gradient Boosting, importance plots:

testweek = 79

fn = paste0("./gbm_fit_reg_w", testweek, ".RData")
if(!file.exists(fn)) stop(paste("File", fn, "not available."))  
model = get(load(fn)) 

importance = data.frame(Variable = as.character(summary(model, plot = FALSE)$var), Importance = summary(model, plot = FALSE)$rel.inf) 
importance = importance[order(importance$Importance, decreasing = TRUE),]
importance$Variable = as.character(importance$Variable)

orig_margins = c(5, 4, 4, 2) + 0.1
par(mar = c(5, 9, 4, 2))  
barplot(importance$Importance, main="Gradient Boosting, Relative Importance", las = 1, cex.names = 0.7, font.main = 1, horiz = TRUE, names.arg = importance$Variable, col = "blue")
par("mar" = orig_margins) 
write.csv(importance, file = paste0("Importance_GB_week", testweek, ".csv"), row.names = FALSE)

# Rank importance:

sum_of_ranks = rep(0, nrow(importance))
names(sum_of_ranks) = importance$Variable

weeks = 31:79

for (testweek in weeks) {                            
  cat(paste("Testweek", testweek, "\n"))
  fn = paste0("gbm_fit_reg_w", testweek, ".RData")
  if(!file.exists(fn)) stop("Model not found.")   
  model = get(load(fn))  
  importance = data.frame(Variable = as.character(summary(model, plot = FALSE)$var), Importance = summary(model, plot = FALSE)$rel.inf, stringsAsFactors = FALSE) 
  importance = importance[order(importance$Importance, decreasing = TRUE),]
  for (i in 1:nrow(importance)) sum_of_ranks[importance$Variable[i]] = sum_of_ranks[importance$Variable[i]] + i
}

mean_of_ranks = sort(sum_of_ranks/length(weeks))

orig_margins = c(5, 4, 4, 2) + 0.1
par(mar = c(5, 9, 4, 2))  
barplot(mean_of_ranks, main="GB, Mean of Ranks of Variable Importance", las = 1, cex.names = 0.7, font.main = 1, horiz = TRUE, names.arg = names(mean_of_ranks), col = "blue")
par("mar" = orig_margins) 

df = data.frame(variable = names(mean_of_ranks), mean_rank = as.numeric(mean_of_ranks))
write.csv(df, file = "GB_mean_of_ranks.csv", row.names = FALSE)



## Calculate RMSE originating from CV and compare with true values:

# GB:

weeks = 31:79

mean_RMSE = data.frame(testweek = integer(), mean_RMSE = numeric(), stringsAsFactors = FALSE) 

for (testweek in weeks) {                            
  cat(paste("Testweek", testweek, "\n"))
  fn = paste0("gbm_fit_reg_w", testweek, ".RData")
  if(!file.exists(fn)) stop("Model not found.")   
  model = get(load(fn))  
  mean_RMSE.row = data.frame(testweek = testweek, mean_RMSE = mean(model$results$RMSE), stringsAsFactors = FALSE)
  mean_RMSE = rbind(mean_RMSE, mean_RMSE.row)
}

reg_results_GB_plus = merge(reg_results_GB, mean_RMSE, by.x = "testweek", by.y = "testweek") 
reg_results_GB_plus = reg_results_GB_plus[complete.cases(reg_results_GB_plus),]

to_plot = c(3,8)
maintxt = "GB, RMSE, true vs. estimated"
matplot(reg_results_GB_plus$testweek, reg_results_GB_plus[,to_plot], col = c("blue", "red"), 
          type = "b", pch = 1, main = maintxt, font.main = 1, xlab = "weeks included", ylab = "RMSE")   
legend("topright", c("estimated by CV", "true by comparison"), col = c("red", "blue"), lwd = 2, lty = c(2,1))    
df = reg_results_GB_plus[,to_plot] 
write.csv(df, file = "RMSE_GB_true_estimated.csv", row.names = FALSE)


# RF:

weeks = 31:79

mean_RMSE = data.frame(testweek = integer(), mean_RMSE = numeric(), stringsAsFactors = FALSE) 

for (testweek in weeks) {                            
  cat(paste("Testweek", testweek, "\n"))
  fn = paste0("rf_fit_reg_w", testweek, ".RData")
  if(!file.exists(fn)) stop("Model not found.")   
  model = get(load(fn))  
  mean_RMSE.row = data.frame(testweek = testweek, mean_RMSE = mean(model$results$RMSE), stringsAsFactors = FALSE)
  mean_RMSE = rbind(mean_RMSE, mean_RMSE.row)
}

reg_results_RF_plus = merge(reg_results_RF, mean_RMSE, by.x = "testweek", by.y = "testweek") 
reg_results_RF_plus = reg_results_RF_plus[complete.cases(reg_results_RF_plus),]

to_plot = c(3,5)
maintxt = "RF, RMSE, true vs. estimated"
matplot(reg_results_RF_plus$testweek, reg_results_RF_plus[,to_plot], col = c("blue", "red"), 
          type = "b", pch = 1, main = maintxt, font.main = 1, xlab = "weeks included", ylab = "RMSE")   
legend("topright", c("estimated by CV", "true by comparison"), col = c("red", "blue"), lwd = 2, lty = c(2,1))    

df = reg_results_RF_plus[,to_plot] 
write.csv(df, file = "RMSE_RF_true_estimated.csv", row.names = FALSE)




## All predictions for all service points, all weeks

first_week = 27           

skip_reg = c("Service_Point_name", "week", "ECDC_Colour", "kommun", "top10_code_nextweek", "cases_per_capita_1w5_nextweek", "Antalpatienter_nextweek", "ServicePoint_postalcode")

reg_results = data.frame(testweek = integer(), 
                         Rsquared_RF = numeric(), Rsquared_GB = numeric(),
                         RMSE_RF = numeric(), RMSE_GB = numeric(),
                         shrinkage = numeric(), depth = numeric(), minobsinnode = integer(), ntrees_GB = integer(), 
			                   ntrees_RF = integer(), stringsAsFactors = FALSE) 

prediction.df = data.frame(Service_Point_name = character(), week = integer(), positivity_1w_nextweek = numeric(), 
                           pred_RF = numeric(), pred_GB = numeric(),  stringsAsFactors = FALSE) 

for (last_week in 31:max(data$week)) {              
  
  weeklydata = select_weeks(data, from = first_week, to = last_week)

  first_train_week = first_week
  testweek = max(weeklydata$week)               
  cat(paste("\n\n ======= Testweek: ", testweek, " ====== \n\n"))         

  traindat_reg = training_data_regression(weeklydata, first_train_week, testweek, skip_reg, impute = FALSE)

  imp = missForest(traindat_reg)$ximp
  traindat_reg = imp
  if(sum(is.na(traindat_reg)) > 0) stop("Still missing values in dataset.")

  true_values = data[data$week == testweek, c("Service_Point_name", "positivity_1w_nextweek")]  # observed values 
  rownames(true_values) = true_values$Service_Point_name

  testdat_reg = test_data_reg(weeklydata, testweek, skip_reg)    # Test data variables are from week 31  ==> predict 32 

  rem = colnames(testdat_reg)[which(!colnames(testdat_reg) %in% colnames(traindat_reg))]
  for (var in rem) testdat_reg[,var] <- NULL

  if(ncol(traindat_reg) != (ncol(testdat_reg) + 1)) stop("Different variables in test- and training data.")
  if(!all(c(colnames(testdat_reg), "positivity_1w_nextweek") == colnames(traindat_reg))) stop("Different variables in test- and training data.") 

  fn_RF = paste0("rf_fit_reg_w", testweek, ".RData")  
  if(!file.exists(fn_RF)) stop("Model not found.")   
  model_RF = get(load(fn_RF))  
 
  fn_GB = paste0("gbm_fit_reg_w", testweek, ".RData")  
  if(!file.exists(fn_GB)) stop("Model not found.")   
  model_GB = get(load(fn_GB))  
  
  Rsquared_RF = Rsquared_RF_tuned(model_RF)    
  Rsquared_GB = Rsquared_GBM_tuned(model_GB)   
  
  # Prediction:
  
  pred_RF = predict(model_RF, newdata = testdat_reg)
  names(pred_RF) = rownames(testdat_reg) 
       
  pred_GB = predict(model_GB, newdata = testdat_reg) 
  names(pred_GB) = rownames(testdat_reg) 
  
  rmse_RF = rmse_reg(pred_RF, true_values) 
  rmse_GB = rmse_reg(pred_GB, true_values) 

  reg_results.row = data.frame(testweek = testweek, 
                           Rsquared_RF = Rsquared_RF, Rsquared_GB = Rsquared_GB,
                           RMSE_RF = rmse_RF, RMSE_GB = rmse_GB,
                           shrinkage = model_GB$bestTune$shrinkage, depth = model_GB$bestTune$interaction.depth, 
			                     minobsinnode = model_GB$bestTune$n.minobsinnode, ntrees_GB = model_GB$bestTune$n.trees, 
			                     ntrees_RF = model_RF$bestTune$mtry, stringsAsFactors = FALSE) 

  reg_results = rbind(reg_results, reg_results.row) 
  tw_vector = rep(testweek, nrow(true_values))
  
  if(!all(rownames(true_values) == names(pred_RF))) stop(" Wrong order of service point names RF.") 
  if(!all(rownames(true_values) == names(pred_GB))) stop(" Wrong order of service point names GB.") 
 
  temp.df = true_values
  temp.df$week = tw_vector
  temp.df$pred_RF = pred_RF  
  temp.df$pred_GB = pred_GB
  temp.df = temp.df[,c(1, 3, 2, 4, 5)]   

  prediction.df = rbind(prediction.df, temp.df)
}      



# RMSR: 

fn = "GB_RF_cumulative.csv"
write.csv(reg_results, file = fn, row.names = FALSE)
file.info(fn)[,c(1,5)]  

maintxt = "RMSE, cumulative"
to_plot = c(4,5)
matplot(reg_results$testweek, reg_results[,to_plot], col = c("red", "blue"), type = "b", pch = 1, main = maintxt, 
          font.main = 1, xlab = "weeks included", ylab = "RMSE")
legend("topright", c("RF", "GB"), col = c("red", "blue"), lwd = 2, lty = c(2,1))     


# Detailed data:

fn = "GB_RF_detailed.csv"
write.csv(prediction.df, file = fn, row.names = FALSE)
file.info(fn)[,c(1,5)]   




## Change the variable names according to table S1:   

gbdat = read.csv("GB_mean_of_ranks.csv")
rfdat = read.csv("RF_mean_of_ranks.csv")


old2new = read.csv(file = "variable_names_quoted.csv")

rfdat$variable[(!(rfdat$variable %in% old2new$Old_name))]   
old2new$Old_name[(!(old2new$Old_name %in% rfdat$variable))] 

rfdat$variable = sub("medel�f.lder", "medel�lder", rfdat$variable)
rfdat$variable[(!(rfdat$variable %in% old2new$Old_name))]   
old2new$Old_name[(!(old2new$Old_name %in% rfdat$variable))] 

nrow(old2new) == nrow(rfdat)  # TRUE

## RF:

for (i in 1:nrow(rfdat)) rfdat$variable = gsub(paste0('\\b', old2new[i,1], '\\b'), old2new[i,2], rfdat$variable)

## Save csv with the new names:
write.csv(rfdat, file = "RF_mean_of_ranks_new.csv", row.names = FALSE)


## Plot:
mean_of_ranks = rfdat$mean_rank
names(mean_of_ranks) = rfdat$variable 

pdf("mean_rank_RF.pdf", width = 9, height = 7)
orig_margins = c(5, 4, 4, 2) + 0.1
par(mar = c(5, 15, 4, 2))  
barplot(mean_of_ranks, main="RF, Mean of Ranks of Variable Importance", las = 1, cex.names = 0.7, font.main = 1, horiz = TRUE, names.arg = names(mean_of_ranks), col = "blue")
par("mar" = orig_margins) 
dev.off()



## GB:

gbdat$variable[(!(gbdat$variable %in% old2new$Old_name))]   
old2new$Old_name[(!(old2new$Old_name %in% gbdat$variable))] 

gbdat$variable = sub("medel�f.lder", "medel�lder", gbdat$variable)

gbdat$variable[(!(gbdat$variable %in% old2new$Old_name))]   
old2new$Old_name[(!(old2new$Old_name %in% gbdat$variable))] 

nrow(old2new) == nrow(gbdat)  # TRUE  

for (i in 1:nrow(gbdat)) gbdat$variable = gsub(paste0('\\b', old2new[i,1], '\\b'), old2new[i,2], gbdat$variable)

# Save csv with the new names:
write.csv(gbdat, file = "GB_mean_of_ranks_new.csv", row.names = FALSE)

## Plot:
mean_of_ranks = gbdat$mean_rank
names(mean_of_ranks) = gbdat$variable 

pdf("mean_rank_GB.pdf", width = 9, height = 7)
orig_margins = c(5, 4, 4, 2) + 0.1
par(mar = c(5, 15, 4, 2))  
barplot(mean_of_ranks, main="GB, Mean of Ranks of Variable Importance", las = 1, cex.names = 0.7, font.main = 1, horiz = TRUE, names.arg = names(mean_of_ranks), col = "blue")
par("mar" = orig_margins) 
dev.off()





