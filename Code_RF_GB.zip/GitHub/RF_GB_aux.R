

## +++ Auxiliary functions for Covid hotspot prediction

# contains functions for regression and classification 

# uwe.menzel@medsci.uu.se  



## Select weeks for cumulative weekly results:

select_weeks <- function(data, from, to)  {
  if(!("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  if(!(from) %in% data$week) stop("Illegal week specified (from).")
  if(!(to) %in% data$week) stop("Illegal week specified (to).")  
  d = data[(data$week >= from) & (data$week <= to), ]
  cat(paste("Remaining weeks:", paste(unique(d$week), collapse = " "), "\n"))
  cat(paste("Number of remaining rows:", nrow(d), " Number of columns:", ncol(d), "\n"))
  return(d)
}



## Count of top10_codes == 1 for each week:

show_nr_top10 <- function(data) {
  if(is.null(data$week)) stop("No 'week' column in the data frame.")
  nr.wrong = 0
  for (week in min(data[["week"]]):max(data[["week"]])) {
    nr = sum(data[data$week == week, "top10_code"] == 1)  
    if(nr == 10) {
      cat(paste("Week:", week, "number of class-1 samples:", nr, "\n")) 
    } else {
      cat(paste("Week:", week, "number of class-1 samples:", nr, " *** \n")) 
      nr.wrong = nr.wrong + 1
    }
  }
  return(nr.wrong)
}



## Convert class variable to character - for the caret package:

convert_class <- function(traindat, varble) {  
  if(class(traindat[, varble]) == "character") stop("The input variable is already of type 'character'.")
  traindat[, varble] = as.character(traindat[, varble]) 
  traindat[, varble] = gsub("0", "Class0", traindat[, varble])
  traindat[, varble] = gsub("1", "Class1", traindat[, varble])
  cat(paste("New class identifiers:", paste(unique(traindat[, varble]), collapse = " "), "\n"))
  print(table(traindat[, varble]))
  cat("\n")
  return(traindat)  
} 




## ROC curves: 

ROC_curves <- function(model_list, file = "ROC.png", header = "ROC curves")  {
  
  if(!is.list(model_list)) stop("First argument must be a list.")
  colvec = c("black", "red", "blue", "green", "brown", "pink")
  aucdf = data.frame(model = character(), AUC = numeric())
  par(mar=c(5.1, 4.1, 4.1, 2.1)) # default
  
  i = 0
  for (model in model_list) {  # model = simple_fit 
    if(sum(class(model) == "train") == 0) stop(paste("Model '", names(model_list)[i], "' is not an appropiate model."))
    i = i + 1  
    area = AUC(model, data = traindat)
    print(area$auc)
    aucrow = data.frame(model = names(model_list)[i], AUC = round(as.numeric(area$auc),4))
    aucdf = rbind(aucdf, aucrow) 
    rocdf = data.frame(TP = area$sensitivities, FP = 1- area$specificities)
    if (i == 1) {
      plot(rocdf$FP, rocdf$TP, xlab = "FP", ylab = "TP", col = colvec[i], pch = ".", cex = 1.5, main = header, font.main = 1)
    } else {
      points(rocdf$FP, rocdf$TP, xlab = "FP", ylab = "TP", col = colvec[i], pch = ".", cex = 1.5)    
    }
  } 
  
  legend("bottomright", names(model_list), lty = 1, lwd = 1.5, col = colvec[1:length(names(model_list))])
  dev.copy(png, file = file, units="in", width = 5, height = 5, res = 300) 
  dev.off()
  
  cat(paste("Plot with ROC curves saved to:", file, "\n"))
  aucdf = aucdf[order(aucdf$AUC, decreasing = TRUE),]
  return(aucdf)
}




## Area under ROC curve:

get_auc <- function(model, data) { 
  predicted = predict(model, data, type = "prob")[, "Class1"]
  true = data$top10_code_nextweek
  return(roc(true, predicted))  
}

AUC <- function(model, data) {  
  # require(pROC)
  predicted = predict(model, data, type = "prob")[,2]
  true = data[,ncol(data)]
  return(roc(true, predicted)) 
}




## Differences between models: 

compmods <- function(models) {
  if(!is.list(models)) stop("First argument must be a list.")
  if(is.null(names(models))) stop("Please provide a named list.")
  mod_pairs = t(combn(names(models), 2))
  comdf = data.frame(model_1 = character(), model_2 = character(), pvalue = numeric())
  for (i in 1:nrow(mod_pairs)) {
    res = compare_models(models[[mod_pairs[i,1]]], models[[mod_pairs[i,2]]])
    comrow = data.frame(model_1 = mod_pairs[i,1], model_2 = mod_pairs[i,2], pvalue = signif(res$p.value, 5))
    comdf = rbind(comdf, comrow) 
  }
  return(comdf)
}




## Rsquared for tuned models, GBM: 

Rsquared_GBM_tuned <- function(model) {
  if(sum(class(model) == "train") == 0) stop("The 1st argument must be a model created by 'caret::train'.") 
  if(is.null(model$bestTune)) stop("The invoked model must have been created with tuning.")
  
  n.trees = model$bestTune$n.trees                     
  interaction.depth = model$bestTune$interaction.depth 
  shrinkage = model$bestTune$shrinkage                
  n.minobsinnode = model$bestTune$n.minobsinnode        
  
  l1 = model$results$n.trees == n.trees
  l2 = model$results$interaction.depth == interaction.depth 
  l3 = model$results$shrinkage == shrinkage
  l4 = model$results$n.minobsinnode == n.minobsinnode
  ind = which(l1 & l2 & l3 & l4) 
  
  cat("\nBest parameters:\n")
  print(model$results[ind,])
  cat("\n")
  Rsquared = model$results$Rsquared[ind]
  return(Rsquared)
}




## Rsquared for tuned models, RF:

Rsquared_RF_tuned <- function(model) {
  if(sum(class(model) == "train") == 0) stop("The 1st argument must be a model created by 'caret::train'.") 
  if(is.null(model$bestTune)) stop("The invoked model must have been created with tuning.")
  print(head(model$results[order(model$results$Rsquared, decreasing = TRUE),]))  
  mtry = model$bestTune$mtry  # 2
  ind = which(model$results$mtry == mtry)  
  cat("\nBest parameters:\n")
  print(model$results[ind,])
  Rsquared = model$results$Rsquared[ind]
  return(Rsquared)
}




## Extract the hotspots for a certain week (for comparison with prediction):

get_hotspots <- function(data, week) {  
  if(is.null(data$week)) stop("Data must have a 'week' column.")
  if(is.null(data$top10_code)) stop("Data must have a 'top10_code' column.")
  if(is.null(data$Service_Point_name)) stop("Data must have a 'Service_Point_name' column.")
  if(week > max(data$week)) stop("parameter 'week' is too big. Not included in the data set.")
  hotspots = data[(data$week == week) & (data$top10_code == 1), "Service_Point_name"]
  if(length(hotspots) != 10) stop("This week doesn't seem to have 10 hotspots.")
  cat(paste("Hotspots for week", week, ":\n"))
  print(hotspots)
  return(hotspots)
}




## Variable importance for RF:

plot_imp_RF <- function(model, fn = "Variable_importance_RF.png") {
  if(sum(class(model) == "train") == 0) stop("The 1st argument must be a model created by 'caret::train'.")
  if(is.null(model$finalModel$importance)) stop("Incorrect model.")
  importance = data.frame(Variable = rownames(model$finalModel$importance), Importance = model$finalModel$importance[,1])
  importance = importance[order(importance$Importance, decreasing = TRUE),]
  print(head(importance, 10))
  orig_margins = c(5.1, 4.1, 4.1, 2.1)
  par(mar = c(5, 9, 4, 2))  
  barplot(importance$Importance, main="Relative Importance", las = 1, cex.names = 0.7, font.main = 1, horiz = TRUE, names.arg = importance$Variable, col = "blue")
  par("mar" = orig_margins) 
  dev.copy(png, file = fn, units="in", width=5, height=5, res=300) 
  dev.off()
  par(mar = orig_margins)
  cat(paste("\nPlot saved to '", fn, "'.\n"))
}




## Variable importance for GBM:

plot_imp_GBM <- function(model, fn = "Variable_importance_GBM.png") {
  if(sum(class(model) == "train") == 0) stop("The 1st argument must be a model created by 'caret::train'.")
  if(is.null(summary(model, plot = FALSE)$var)) stop("Incorrect model, probably no GBM model.")
  if(is.null(summary(model, plot = FALSE)$rel.inf)) stop("Incorrect model, probably no GBM model.")
  importance = data.frame(Variable = as.character(summary(model, plot = FALSE)$var), Importance = summary(model, plot = FALSE)$rel.inf) 
  importance = importance[order(importance$Importance, decreasing = TRUE),]
  print(head(importance, 10))
  orig_margins = c(5.1, 4.1, 4.1, 2.1)
  par(mar = c(5, 9, 4, 2))  
  barplot(importance$Importance, main="Relative Importance", las = 1, cex.names = 0.7, font.main = 1, horiz = TRUE, names.arg = importance$Variable, col = "blue")
  par("mar" = orig_margins) 
  dev.copy(png, file = fn, units="in", width=5, height=5, res=300) 
  dev.off()
  par(mar = orig_margins)
  cat(paste("\nPlot saved to '", fn, "'.\n"))
}




## Training data, for classification:

training_data_classification <- function(data, first_train_week, testweek, skip, impute) {
  
  if(!"top10_code_nextweek" %in% colnames(data)) stop("Data must have a column 'top10_code_nextweek'")
  if(!"week" %in% colnames(data)) stop("Data must have a column 'week'") 
  if(!"Service_Point_name" %in% colnames(data)) stop("Data must have a column 'Service_Point_name'") 
  
  traindat = data[(data$week >= first_train_week) & (data$week < testweek),] 
  if(max(traindat$week) > testweek - 1) stop("This is nor a realistic training set, model would see the association to be predicted.\n")
  rownames(traindat) = paste(traindat$Service_Point_name, traindat$week, sep = "_") 
  traindat$Service_Point_name <- NULL                 
  for (var in skip) traindat[,var] <- NULL  
  if(!impute) {
    cat(paste("No imputation. Number of incomplete cases to be removed:", sum(!complete.cases(traindat)), "\n"))
    traindat = traindat[complete.cases(traindat),]
  } else {
    cat("Running imputation\n") 
  }  
  col_order = c(setdiff(colnames(traindat), "top10_code_nextweek"), "top10_code_nextweek") 
  traindat = traindat[,col_order]  
  if("top10_code" %in% colnames(traindat))  traindat$top10_code = as.factor(traindat$top10_code)  
  traindat$top10_code_nextweek = as.factor(traindat$top10_code_nextweek) 
  cat(paste("Training data variables range from week", first_train_week, "to week", testweek - 1, "\n"))
  cat(paste("Training data classes range from week", first_train_week + 1, "to week", testweek, "\n"))
  cat(paste("Training data has", nrow(traindat), "rows and", ncol(traindat), "columns.\n\n"))  
  return(traindat)
}




## Training data, for regression:

training_data_regression <- function(data, first_train_week, testweek, skip, impute) {
  
  if(!"positivity_1w_nextweek" %in% colnames(data)) stop("Data must have a column 'positivity_1w_nextweek'")
  if(!"week" %in% colnames(data)) stop("Data must have a column 'week'") 
  if(!"Service_Point_name" %in% colnames(data)) stop("Data must have a column 'Service_Point_name'") 
  
  traindat = data[(data$week >= first_train_week) & (data$week < testweek),]  
  if(max(traindat$week) > testweek - 1) stop("This is not a realistic training set, model would see the association to be predicted.\n")
  rownames(traindat) = paste(traindat$Service_Point_name, traindat$week, sep = "_") 
  traindat$Service_Point_name <- NULL 
  for (var in skip) traindat[,var] <- NULL  
  if(!impute) {
    cat(paste("No imputation. Number of incomplete cases (NOT removed):", sum(!complete.cases(traindat)), "\n"))
  } else {
    cat("Running imputation\n") 
  }  
  col_order = c(setdiff(colnames(traindat), "positivity_1w_nextweek"), "positivity_1w_nextweek")  
  traindat = traindat[,col_order]  # make sure "positivity_1w_nextweek" is in the last column
  if("top10_code" %in% colnames(traindat))  traindat$top10_code = as.factor(traindat$top10_code)  
  cat(paste("Training data variables range from week", first_train_week, "to week", testweek - 1, "\n"))
  cat(paste("Training data classes range from week", first_train_week + 1, "to week", testweek, "\n"))
  cat(paste("Training data has", nrow(traindat), "rows and", ncol(traindat), "columns.\n\n"))  
  return(traindat)
}




## Root mean squared error, regression: 

rmse_reg <- function(fitted, true)  {
  if(is.null(true$Service_Point_name)) stop("No 'Service_Point_name' column.") 
  if(!all(names(fitted) == true$Service_Point_name)) stop("Wrong order of service points.")
  rmse = sqrt(sum((true$positivity_1w_nextweek - fitted)^2)/length(fitted))
  return(rmse)
}




## Test data, classification:

test_data <- function(data, testweek, skip) {  
  if(!"week" %in% colnames(data)) stop("Data must have a column 'week'") 
  if(!"Service_Point_name" %in% colnames(data)) stop("Data must have a column 'Service_Point_name'") 
  
  testdat = data[data$week == testweek,]               
  rownames(testdat) = testdat$Service_Point_name                  
  testdat$Service_Point_name <- NULL  
  for (var in skip) testdat[,var] <- NULL              
  testdat$positivity_1w_nextweek <- NULL               
  testdat$top10_code_nextweek <- NULL                   
  indNA = which(!complete.cases(testdat))
  if(length(indNA) == 0) {
    cat("No missing data in the test set.\n")
  } else {
    cat(paste("Missing in test set:", rownames(testdat)[indNA], "\n")) 
    testdat = testdat[complete.cases(testdat),]        
  }
  if("top10_code" %in% colnames(testdat))  testdat$top10_code = as.factor(testdat$top10_code)
  cat(paste("Test data variables are from week", testweek, ".\n")) 
  return(testdat)
}




## Test data, regression:

test_data_reg <- function(data, testweek, skip) {  
  if(!"week" %in% colnames(data)) stop("Data must have a column 'week'") 
  if(!"Service_Point_name" %in% colnames(data)) stop("Data must have a column 'Service_Point_name'") 
  
  testdat = data[data$week == testweek,]               
  rownames(testdat) = testdat$Service_Point_name                  
  testdat$Service_Point_name <- NULL  
  for (var in skip) testdat[,var] <- NULL              
  testdat$positivity_1w_nextweek <- NULL               
  testdat$top10_code_nextweek <- NULL                   
  indNA = which(!complete.cases(testdat))
  if(length(indNA) == 0) {
    cat("No missing data in the test set.\n")
  } 
  if("top10_code" %in% colnames(testdat))  testdat$top10_code = as.factor(testdat$top10_code)
  cat(paste("Test data variables are from week", testweek, ".\n")) 
  return(testdat)
}




## True data,  classification:

true_data <- function(data, testweek)   {
  
  if(!"week" %in% colnames(data)) stop("Data must have a column 'week'")
  if(!"Service_Point_name" %in% colnames(data)) stop("Data must have a column 'Service_Point_name'")
  if(!"top10_code" %in% colnames(data)) stop("Data must have a column 'top10_code'") 
  if(!"top10_code_nextweek" %in% colnames(data)) stop("Data must have a column 'top10_code_nextweek'") 
  if(!(testweek + 1) %in% data$week) stop("Illegal class week.")
  
  truedat1 = data[data$week == testweek + 1, c("Service_Point_name", "top10_code")]   
  rownames(truedat1) = truedat1$Service_Point_name
  truedat1$Service_Point_name <- NULL 
  # OR:
  truedat = data[data$week == testweek, c("Service_Point_name", "top10_code_nextweek")]  
  rownames(truedat) = truedat$Service_Point_name
  truedat$Service_Point_name <- NULL  
  if(!all(rownames(truedat) == rownames(truedat1))) stop("Different rownames when true data are checked.")  
  if(!all(truedat1$top10_code == truedat$top10_code_nextweek))  stop("Different top10 codes when true data are checked.")
  cat(paste("Class data is from week", testweek + 1, ".\n\n"))  
  truedat$top10_code_nextweek = as.factor(truedat$top10_code_nextweek)
  return(truedat)
}




## True data,  regression:

true_data_reg <- function(data, testweek)   {
  
  if(!"week" %in% colnames(data)) stop("Data must have a column 'week'")
  if(!"Service_Point_name" %in% colnames(data)) stop("Data must have a column 'Service_Point_name'")
  if(!"positivity_1w" %in% colnames(data)) stop("Data must have a column 'positivity_1w'") 
  if(!"positivity_1w_nextweek" %in% colnames(data)) stop("Data must have a column 'positivity_1w_nextweek'") 
  if(!(testweek + 1) %in% data$week) stop("Illegal class week.")
  
  truedat1 = data[data$week == testweek + 1, c("Service_Point_name", "positivity_1w")]   
  rownames(truedat1) = truedat1$Service_Point_name
  truedat1 = truedat1[complete.cases(truedat1),]
  truedat1$Service_Point_name <- NULL 
  # OR:
  truedat = data[data$week == testweek, c("Service_Point_name", "positivity_1w_nextweek")]  
  rownames(truedat) = truedat$Service_Point_name
  truedat = truedat[complete.cases(truedat),]
  truedat$Service_Point_name <- NULL 
  
  if(!all(rownames(truedat) == rownames(truedat1))) stop("Different rownames when true data are checked.")  
  if(!all(truedat1$positivity_1w == truedat$positivity_1w_nextweek))  stop("Different positivity values when true data are checked.")
  cat(paste("Response values are from week", testweek + 1, ".\n\n"))  
  if(!is.numeric(truedat$positivity_1w_nextweek)) stop("Variable 'positivity_1w_nextweek' is not numeric.")
  return(truedat)
}





## Create the RF model, classification:

get_RF_model <- function(traindat, mtry = floor(sqrt(ncol(traindat)-1)), stratify = FALSE, ntree = 1000, classwt = NULL, IDcol, replace = TRUE, strata, sampsize, trace = 200)  {
  
  require(randomForest)			
  
  if(!is.logical(IDcol)) stop("Parameter 'IDcol' must be of type 'logical'.")
  if(!is.logical(stratify)) stop("Parameter 'IDcol' must be of type 'logical'.")
  if(!is.data.frame(traindat)) stop("First argument must be a data frame.")
  if(!is.logical(replace)) stop("Parameter 'replace' must be of type 'logical'.")
  traindat[,ncol(traindat)] = as.factor(traindat[,ncol(traindat)])
  
  if(IDcol) traindat = traindat[, -1]  # in case first column is some identifier 
  cat(paste("Training set ==> rows:", nrow(traindat), " ; columns:", ncol(traindat),"\n")) 
  cat(paste("Response levels:", paste(levels(traindat[,ncol(traindat)]), collapse = "  "), "\n"))
  cat(paste("Number of samples in the training set:", nrow(traindat), "\n"))
  
  if(stratify) {  
    model <- randomForest(traindat[,-ncol(traindat)], traindat[,ncol(traindat)], mtry = mtry, 
                          classwt = classwt, ntree = ntree, importance = TRUE, 
                          replace = replace, strata = strata, sampsize = sampsize, 
                          proximity = TRUE, keep.forest = TRUE, do.trace = ceiling(ntree/10))  
  } else {
    model <- randomForest(traindat[,-ncol(traindat)], traindat[,ncol(traindat)], mtry = mtry, 
                          classwt = classwt, ntree = ntree, importance = TRUE, 
                          proximity = TRUE, keep.forest = TRUE, do.trace = ceiling(ntree/10))     
  }
  
  if(class(model) != "randomForest") stop("Creation of RF model failed.")
  return(model)   
}




## Prediction, for classification: 

RF_predict <- function(model, testdat, truedat = NULL)  {
  
  require(randomForest)			
  if(!is.data.frame(testdat)) stop("Test data should be a data frame.")
  if(!is.null(truedat)) if(!is.data.frame(truedat)) stop("True data should be a data frame.")
  if(!is.null(truedat)) if(!"top10_code_nextweek" %in% colnames(truedat)) stop("True data must have a column 'top10_code_nextweek'") 
  if(class(model) != "randomForest") stop("First argument must be a Random Forest model.")
  if(model$type != "classification") stop("This is not a classification model.")
  if(!all(names(model$forest$xlevels) == colnames(testdat))) stop("Different variable names in model and test data (top10_code.x set?)")   
  
  if(!is.null(truedat)) {
    if(!setequal(rownames(testdat), rownames(truedat))) {   
      cat("Synchronizing test data samples and true class samples.\n")  
      dat = merge(testdat, truedat, by = "row.names")
      rownames(dat) = dat$Row.names
      dat$Row.names <- NULL
      class.ind = which(colnames(dat) == "top10_code_nextweek")  
      testdat = subset(dat, select=-class.ind)   
      truedat = subset(dat, select=class.ind)  
      truedat$top10_code_nextweek = as.factor(truedat$top10_code_nextweek)
      if(!all(rownames(testdat) == rownames(truedat))) stop("Test and true data still have different identifiers.")
    }
  }
  
  prediction = predict(model, newdata = testdat, proximity = TRUE)		
  class1_predicted = names(prediction$predicted)[which(prediction$predicted == 1)]
  cat(paste("Number of class 1 predictions:", length(class1_predicted), "\n"))
  
  pred2 = predict(model, newdata = testdat, type = "prob", proximity = TRUE)			
  probs = pred2$predicted[order(pred2$predicted[,2], decreasing = TRUE),]
  pos = sum(as.numeric(prediction$predicted) - 1)  
  neg = length(prediction$predicted) - pos            
  
  if(!is.null(truedat)) {
    percent.correctly.predicted = sum(prediction$predicted == as.factor(truedat[,1]))/length(truedat[,1])*100.0	
    cat(paste("Correctly predicted:", round(percent.correctly.predicted,2), "%\n")) 
    conf.mat = table(prediction$predicted, truedat[,1], useNA = "ifany", dnn = c("True","Predicted"))  
    TN = conf.mat[1,1]   
    FN = conf.mat[1,2]   
    TP = conf.mat[2,2]     
    FP = conf.mat[2,1]    
    cat(paste("POS =", pos, "NEG =", neg, "TN =", TN, "FN =", FN, "TP =", TP, "FP =", FP, "correct =", round(percent.correctly.predicted,2),"%\n\n"))
    print(conf.mat)
    cat("\n")
  } else {
    cat(paste("POS =", pos, "NEG =", neg, "\n\n"))  
  }
  
  res = list()
  res[["class1_predicted"]] = class1_predicted
  res[["prediction"]] = prediction$predicted  
  res[["proximity"]] = prediction$proximity
  res[["probabilities"]] = probs
  res[["best.10"]] = rownames(head(res$probabilities[order(res$probabilities[,2], decreasing = TRUE),],10))
  res[["best.15"]] = rownames(head(res$probabilities[order(res$probabilities[,2], decreasing = TRUE),],15))
  res[["best.20"]] = rownames(head(res$probabilities[order(res$probabilities[,2], decreasing = TRUE),],20))
  
  if(!is.null(truedat)) {
    res[["confusion"]] = conf.mat
    res[["accuracy"]] = round(percent.correctly.predicted, 2) 
    # Pick the best hits from the probability values:
    res[["correct.10"]] = length(intersect(res[["best.10"]], rownames(truedat)[which(truedat[,1] == 1)])) 
    res[["correct.15"]] = length(intersect(res[["best.15"]], rownames(truedat)[which(truedat[,1] == 1)])) 
    res[["correct.20"]] = length(intersect(res[["best.20"]], rownames(truedat)[which(truedat[,1] == 1)])) 
    res[["TN"]] = TN
    res[["FN"]] = FN
    res[["TP"]] = TP
    res[["FP"]] = FP
  }
  return(res)
}




## Create the RF model, regression: 

get_RF_model_reg <- function(traindat_reg, mtry = floor(sqrt(ncol(traindat_reg)-1)), stratify = FALSE, 
                             ntree = 1000, classwt = NULL, IDcol, replace = TRUE, strata, sampsize, trace = 200)  {
  
  require(randomForest)			
  
  if(!is.logical(IDcol)) stop("Parameter 'IDcol' must be of type 'logical'.")
  if(!is.logical(stratify)) stop("Parameter 'IDcol' must be of type 'logical'.")
  if(!is.data.frame(traindat_reg)) stop("First argument must be a data frame.")
  if(!is.logical(replace)) stop("Parameter 'replace' must be of type 'logical'.")
  if(!is.numeric(traindat_reg[,ncol(traindat_reg)])) stop("Last column is not numeric - no regression can be made.")
  if(IDcol) traindat_reg = traindat_reg[, -1]  # in case first column is some identifier 
  cat(paste("Training set ==> rows:", nrow(traindat_reg), " ; columns:", ncol(traindat_reg),"\n")) 
  cat(paste("Response range:", min(traindat_reg[,ncol(traindat_reg)]), "to", round(max(traindat_reg[,ncol(traindat_reg)]),3), "\n"))
  cat(paste("Number of samples in the training set:", nrow(traindat_reg), "\n"))
  
  if(stratify) {  
    model <- randomForest(traindat_reg[,-ncol(traindat_reg)], traindat_reg[,ncol(traindat_reg)], mtry = mtry, 
                          classwt = classwt, ntree = ntree, importance = TRUE, 
                          replace = replace, strata = strata, sampsize = sampsize, 
                          proximity = TRUE, keep.forest = TRUE, do.trace = ceiling(ntree/10))  
  } else {
    model <- randomForest(traindat_reg[,-ncol(traindat_reg)], traindat_reg[,ncol(traindat_reg)], mtry = mtry, 
                          classwt = classwt, ntree = ntree, importance = TRUE, 
                          proximity = TRUE, keep.forest = TRUE, do.trace = ceiling(ntree/10))      
  }
  plot(model)  
  if(class(model) != "randomForest") stop("Creation of RF model failed.")
  return(model)   
}




## Prediction, for regression: 

RF_predict_reg <- function(model, testdat, truedat = NULL)  {
  
  require(randomForest)			
  if(!is.data.frame(testdat)) stop("Test data should be a data frame.")
  if(!is.null(truedat)) if(!is.data.frame(truedat)) stop("True data should be a data frame.")
  if(!is.null(truedat)) if(!"positivity_1w_nextweek" %in% colnames(truedat)) stop("True data must have a column 'positivity_1w_nextweek'") 
  if(class(model) != "randomForest") stop("First argument must be a Random Forest model.")
  if(model$type != "regression") stop("This is not a regression model.")
  if(!all(names(model$forest$xlevels) == colnames(testdat))) stop("Different variable names in model and test data.")   
  
  if(!is.null(truedat)) {
    if(!setequal(rownames(testdat), rownames(truedat))) {   
      cat("Synchronizing test data samples and true class samples.\n")  
      dat = merge(testdat, truedat, by = "row.names")
      rownames(dat) = dat$Row.names
      dat$Row.names <- NULL
      class.ind = which(colnames(dat) == "positivity_1w_nextweek")  
      testdat = subset(dat, select = -class.ind)   
      truedat = subset(dat, select = class.ind)  
      if(!all(rownames(testdat) == rownames(truedat))) stop("Test and true data still have different identifiers.")
    }
  }
  
  prediction = predict(model, newdata = testdat, proximity = TRUE)		
  predicted.values = prediction$predicted
  if(!all(names(predicted.values) == rownames(testdat))) stop("Different row names in test- and true data.")

  var.explained = (1 - sum((model$y - model$predicted)^2) / sum((model$y - mean(model$y))^2)) * 100  
  if(!is.null(truedat)) {
    residuals = predicted.values - truedat[,1]
    test.err = mean(residuals^2)     # Mean Squared Test Error
    plot(truedat[,1], predicted.values, xlab = "true values", ylab = "predicted")
    abline(coef = c(0,1), col = "red", lty = 2)
  }
  
  res = list()
  res[["predicted.values"]] = predicted.values 
  res[["var.explained"]] = var.explained
  res[["proximity"]] = prediction$proximity
  res[["best.10"]] = head(sort(predicted.values, decreasing = TRUE),10)
  res[["best.15"]] = head(sort(predicted.values, decreasing = TRUE),15)
  res[["best.20"]] = head(sort(predicted.values, decreasing = TRUE),20)
  if(!is.null(truedat)) {
    res[["test.err"]] = test.err
  }
  return(res)
}




## Optimize mtry:

best_mtry <- function(traindat, mtry.low, mtry.high, stratify = FALSE, ntree = ntree, 
                      classwt = NULL, IDcol = FALSE, replace = replace, strata = strata, sampsize = sampsize) {
  
  oob.values = data.frame(mtry = integer(), oob.error = numeric())
  for (mtry in mtry.low:mtry.high) {
    cat(paste("\nTesting mtry =", mtry, "\n")) 
    if(stratify) {
      mod = get_RF_model(traindat, mtry = mtry, stratify = TRUE,  ntree = ntree, 
                         classwt = classwt, IDcol = IDcol, replace = replace, strata = strata, sampsize = sampsize, trace = ceiling(ntree/10))
    } else {
      mod = get_RF_model(traindat, mtry = mtry, stratify = FALSE, ntree = ntree, 
                         classwt = classwt, IDcol = IDcol, trace = ceiling(ntree/10))  
    }
    oob.error = mod$err.rate[nrow(mod$err.rate),1]
    oob.row = data.frame(mtry = mtry, oob.error = oob.error)
    oob.values = rbind(oob.values, oob.row)
  }
  plot(oob.values$mtry, oob.values$oob.error, xlab = "mtry", ylab = "OOB-Error", col = "red", type = "b")  
  best.mtry = oob.values$mtry[which(oob.values$oob.error == min(oob.values$oob.error))]
  
  res = list()
  res[["best.mtry"]] = best.mtry
  res[["oob.values"]] = oob.values    
  return(res)   
}




## Time evolution of top10_codes, with stadsdel: 

top10_evolution_stadsdel <- function(data) {  
  
  if(!("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  if(!("stadsdel" %in% colnames(data))) stop("Data frame must have a column named 'stadsdel'")  
  if(!("top10_code" %in% colnames(data))) stop("Data frame must have a column named 'top10_code'")  
  
  df = data[,c("week", "stadsdel", "top10_code")]
  df$stadsdel = as.numeric(factor(df$stadsdel))  
  df = df[df$top10_code == 1, c(1,2)]
  
  plot(df$week, df$stadsdel, main = "Hotspot-stadsdel vs. week", font.main = 1, col = df$stadsdel, pch = 16, cex = 0.5, xlab = "week", ylab = "stadsdel")
  for (i in 1:89) abline(h = i, lwd = 0.3, col = "lightgrey", lty = 3)
  
  fn = "stadsdel_vs_week.tiff"
  tiff(fn, units="in", width=5, height=5, res=300)
  plot(df$week, df$stadsdel, main = "Hotspot-stadsdel vs. week", font.main = 1, col = df$stadsdel, pch = 16, cex = 0.5, xlab = "week", ylab = "stadsdel")
  for (i in seq(1, 89, by = 2)) abline(h = i, lwd = 0.3, col = "lightgrey", lty = 3)
  dev.off()
  cat(paste("Plot saved to:", fn, "\n"))  
  
  sdel = numeric()
  num_top10 = numeric()
  for (i in 1:89) {
    sdel[i] = unique(data$stadsdel)[i]
    num_top10[i] = sum(df$stadsdel == i)
  }
  df1 = data.frame(stadsdel = sdel, number_top10 = num_top10)
  df1 = df1[order(df1$number_top10, decreasing = TRUE),]
  df1
}




## Time evolution of top10_codes, with Service_Point_name: 

top10_evolution <- function(data) {  # all weeks 
  
  if(!("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  if(!("Service_Point_name" %in% colnames(data))) stop("Data frame must have a column named 'Service_Point_name'")  
  if(!("top10_code" %in% colnames(data))) stop("Data frame must have a column named 'top10_code'")  
  
  df = data[data$top10_code == 1, c("week", "Service_Point_name", "top10_code")]
  df1 = as.data.frame(sort(table(df$Service_Point_name), decreasing = TRUE))
  colnames(df1) = c("ServicePoint", "Frequency")
  
  # for plotting:
  df$Service_Point_name = as.numeric(factor(df$Service_Point_name)) 
  par(mar=c(5,4,4,2))
  plot(df$week, df$Service_Point_name, main = "Hotspot-ServicePoint vs. week", font.main = 1, 
       col = df$Service_Point_name, pch = 16, cex = 0.5, xlab = "week", ylab = "ServicePoint")
  for (i in 1:nrow(df)) abline(h = i, lwd = 0.3, col = "lightgrey", lty = 3)
  fn = "ServicePoint_vs_week.png"
  dev.copy(png, file = fn, units="in", width=5, height=5, res=300) 
  dev.off()
  cat(paste("Plot saved to:", fn, "\n"))  
  return(df1) 
}




## Get the number and percentage of missing values for each variable:

missing_data <- function(data) {
  num_NA = apply(data, 2, function(x) sum(is.na(x))) 
  perc_NA = num_NA / nrow(data) * 100.0 
  df = data.frame(variable = names(num_NA), number = num_NA, percent =  round(perc_NA,2))  
  rownames(df) = 1:nrow(df)  
  df
}


missing_per_week <- function(data) {
  if(! ("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  for (w in unique(data$week)) {   
    wdata = get_week(data, w)
    num_NA = apply(wdata, 2, function(x) sum(is.na(x))) 
    perc_NA = num_NA / nrow(wdata) * 100.0 
    df = data.frame(variable = names(num_NA), number = num_NA, percent =  round(perc_NA,2)) 
    # cat(paste("Week:", w, "\n"))
    if(sum(df$number > 0) > 0) {
      cat(paste("Week:", w, "\n"))
      df1 = df[df$number > 0,]
      rownames(df1) = 1:nrow(df1)
    } 
  }
}


missing_in_week <- function(data) {
  if(! ("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  for (w in unique(data$week)) {   
    wdata = get_week(data, w)
    num_NA = sum(apply(wdata, 2, function(x) sum(is.na(x))))   
    perc_NA = num_NA / nrow(wdata) / ncol(wdata) * 100.0 
    cat(paste("Week:", w, "  number missing:", num_NA, "  percent missing:", round(perc_NA, 2), "\n"))
  }
}



## Gradient of variable:

get_gradient <- function(data, var, week) {    
  if(!("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  if(!("Service_Point_name" %in% colnames(data))) stop("Data frame must have a column named 'Service_Point_name'")
  if(week <  min(unique(data$week)) + 1) stop("week parameter too small.") 
  if(week > max(unique(data$week))) stop("week parameter too big.")
  grad = get_week(data, week)[[var]] - get_week(data, week - 1)[[var]] 
  names(grad) = get_week(data, week)[["Service_Point_name"]]
  grad
}


add_gradient <- function(data, var) {  
  
  if(!class(data[[var]]) %in% c("integer", "numeric")) stop("Cannot calculate gradient for this variable type.")  
  if(!("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  if(!("Service_Point_name" %in% colnames(data))) stop("Data frame must have a column named 'Service_Point_name'")
  weeks = (min(data[["week"]])+1):max(data[["week"]])  
  if(min(weeks) - 1 < min(unique(data$week))) stop("Lower boundary of weeks parameter too small.") 
  if(max(weeks) > max(unique(data$week))) stop("Upper boundary of weeks parameter too big.")

  stacked_grad = vector()  
  for (week in weeks) {   
    grad = get_gradient(data, var, week)  
    stacked_grad = c(stacked_grad, grad) 
  }
  if(sum(data$week %in% weeks) != length(stacked_grad)) stop("Unequal number of rows.")
  
  dat1 = data[order(data$week),]
  dat1 = dat1[dat1$week %in% weeks,] 
  dat1 = cbind(dat1, stacked_grad)
  colnames(dat1)[ncol(dat1)] = paste0("delta_", var) 
  if(!is.null(dat1$delta_top10_code)) {  # for factors
    dat1$delta_top10_code = as.factor(dat1$delta_top10_code) 
  }
  return(dat1)
}



plot_top10_code <- function(data) {
  if(is.null(data$top10_code)) stop("Data must have a 'top10_code' column.")
  if(is.null(data$top10_code_nextweek)) stop("Data must have a 'top10_code_nextweek' column.")
  plot(jitter(as.numeric(data$top10_code)-1), jitter(as.numeric(data$top10_code_nextweek)-1), xlab = "top10_code", ylab = "top10_code_nextweek") 
  or = sum((data$top10_code == 1) & (data$top10_code_nextweek == 1), na.rm = TRUE)    
  ul = sum((data$top10_code == 0) & (data$top10_code_nextweek == 0), na.rm = TRUE)     
  ol = sum((data$top10_code == 0) & (data$top10_code_nextweek == 1), na.rm = TRUE)  
  ur = sum((data$top10_code == 1) & (data$top10_code_nextweek == 0), na.rm = TRUE)    
  text(0, 0.7, paste("n =", ol))
  text(1, 0.7, paste("n =", or))
  text(0, 0.3, paste("n =", ul))
  text(1, 0.3, paste("n =", ur))
}




## Variability of variables:

variety_per_week <-function(data, weeks, variables = "all", show.all = FALSE)  {       
  if(! ("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  if(class(variables) != "character") stop("the parameter 'variables' must be of type 'character'.")  
  if (variables == "all") v = colnames(data) else v = variables                         
  for (week in weeks) {
    wdata = get_week(data, week)                                                         
    cat(paste(" *** week:", week, " *** \n"))  
    for (var in v) {                                                                    
      if (var == "week") next
      if (var == "stadsdel") next
      if (var == "top10_code") next
      variety = length(unique(wdata[[var]])) 
      if(variety > 1) {
        if (show.all) cat(paste("Variable:", var, "variety:", variety, "\n"))  
      } else {
        cat(paste("Variable: '", var, "' is constant troughout this week, the value is:", unique(wdata[[var]]), "\n"))    
      }
    }
  }
}


variety_all_weeks <-function(data, weeks, variables = "all", show.all = FALSE)  {         
  if(! ("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  if(class(variables) != "character") stop("the parameter 'variables' must be of type 'character'.")  
  if (variables == "all") v = colnames(data) else v = variables                        
  
  weekdata = get_week(data, weeks[1]) 
  for (week in weeks[-1]) {                                                                 
    wdata = get_week(data, week)                                                        
    weekdata = rbind(weekdata, wdata)
  }
  
  for (var in v) {                                                                    
    if (var == "week") next
    if (var == "stadsdel") next
    if (var == "top10_code") next
    variety = length(unique(weekdata[[var]]))
    if(variety > 1) {
      if (show.all) cat(paste("Variable:", var, "variety:", variety, "\n"))  
    } else {
      cat(paste("Variable: '", var, "' is constant troughout these weeks, the value is:", unique(wdata[[var]]), "\n"))    
    }    
  }  
}



## Auxiliary function:

get_week <- function(data, week) { 
  if(! ("week" %in% colnames(data))) stop("Data frame must have a column named 'week'")
  wdata = data[data$week == week,]
}




